# Snow & Fireworks Effects - Integration Guide

## Filer der skal bruges

Du skal kun bruge **2 filer**:

1. `effects.js` - Indeholder både sne- og fyrværkeri-effekterne
2. `countdown.js` - Styrer automatisk skift mellem effekterne baseret på dato

## Sådan integrerer du dem

### Metode 1: Direkte i HTML (simplest)

Tilføj disse to script tags før `</body>` tagget i din HTML:

```html
<script src="effects.js"></script>
<script src="countdown.js"></script>
```

**Vigtigt:** `countdown.js` skal komme **efter** `effects.js`!

### Metode 2: Med bundler (Vue, React, etc.)

```javascript
// I din main.js eller index.js
import './effects.js';
import './countdown.js';
```

## Hvordan det virker

- **Sne**: Kører automatisk fra 23. december til 26. december
- **Fyrværkeri**: Kører automatisk fra 30. december til 2. januar
- Systemet checker automatisk datoen hver time og skifter mellem effekterne

## Manuelt kontrol (valgfrit)

Hvis du vil manuelt starte/stoppe effekterne:

```javascript
// Start sne
window.startSnow();

// Stop sne
window.removeSnow();

// Start fyrværkeri
window.startFireworks();

// Stop fyrværkeri
window.removeFireworks();
```

## Krav

- Ingen eksterne afhængigheder
- Virker i alle moderne browsere
- Automatisk responsiv (tilpasser sig skærmstørrelse)
- `pointer-events: none` så navigation ikke påvirkes

## Performance

- Automatisk optimeret for mobil (mindre partikler og eksplosioner)
- Desktop får fuld visuel effekt
- Ingen konflikter med eksisterende kode (alle variabler er i IIFE scope)

