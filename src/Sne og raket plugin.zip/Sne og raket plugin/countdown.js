// Date-based effect manager - controls transition between snow and fireworks
(function() {
  'use strict';

  let checkInterval = null;
  let currentEffect = null; // 'snow', 'fireworks', or null
  
  // Check current date and activate appropriate effect
  function checkDateAndActivate() {
    const now = new Date();
    const month = now.getMonth(); // 0-11 (0 = January)
    const date = now.getDate(); // 1-31
    
    // December is month 11 (0-indexed)
    // January is month 0 (0-indexed)
    
    let shouldBeActive = null;
    
    // Snow: December 23-26
    if (month === 11 && date >= 23 && date <= 26) {
      shouldBeActive = 'snow';
    }
    // Fireworks: December 30-31 and January 1-2
    else if ((month === 11 && date >= 30) || (month === 0 && date <= 2)) {
      shouldBeActive = 'fireworks';
    }
    // Otherwise: no effect
    else {
      shouldBeActive = null;
    }
    
    // Only switch if effect has changed
    if (shouldBeActive !== currentEffect) {
      // Stop current effect
      if (currentEffect === 'snow' && window.removeSnow) {
        window.removeSnow();
      }
      if (currentEffect === 'fireworks' && window.removeFireworks) {
        window.removeFireworks();
      }
      
      // Start new effect
      if (shouldBeActive === 'snow' && window.startSnow) {
        window.startSnow();
      }
      if (shouldBeActive === 'fireworks' && window.startFireworks) {
        window.startFireworks();
      }
      
      currentEffect = shouldBeActive;
    }
  }
  
  // Start checking when DOM is ready
  function startDateCheck() {
    // Check immediately
    checkDateAndActivate();
    
    // Check every hour to catch date changes
    checkInterval = setInterval(() => {
      checkDateAndActivate();
    }, 60 * 60 * 1000); // Check every hour
  }
  
  // Start when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startDateCheck);
  } else {
    startDateCheck();
  }
})();

