// Combined Snow and Fireworks effects - vanilla JavaScript
(function() {
  'use strict';

  // ==================== SNOW EFFECT ====================
  let snowCanvas = null;
  let snowCtx = null;
  let snowAnimationId = null;
  
  // Snowflake class
  class Snowflake {
    constructor() {
      this.x = Math.random() * snowCanvas.width;
      this.y = Math.random() * snowCanvas.height;
      this.size = Math.random() * 3 + 1;
      this.speed = Math.random() * 1 + 0.5;
      this.opacity = Math.random() * 0.5 + 0.3;
      this.wind = Math.random() * 0.5 - 0.25;
    }
    
    update() {
      this.y += this.speed;
      this.x += this.wind + Math.sin(this.y * 0.01) * 0.3;
      
      // Reset if snowflake goes off screen
      if (this.y > snowCanvas.height) {
        this.y = 0;
        this.x = Math.random() * snowCanvas.width;
      }
      
      // Wrap around horizontally
      if (this.x > snowCanvas.width) {
        this.x = 0;
      } else if (this.x < 0) {
        this.x = snowCanvas.width;
      }
    }
    
    draw() {
      snowCtx.beginPath();
      snowCtx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
      snowCtx.fillStyle = `rgba(255, 255, 255, ${this.opacity})`;
      snowCtx.fill();
    }
  }
  
  // Initialize snowflakes
  const snowflakes = [];
  const snowflakeCount = 150;
  
  function initSnowflakes() {
    snowflakes.length = 0;
    for (let i = 0; i < snowflakeCount; i++) {
      snowflakes.push(new Snowflake());
    }
  }
  
  // Resize snow canvas
  function resizeSnowCanvas() {
    snowCanvas.width = window.innerWidth;
    snowCanvas.height = window.innerHeight;
  }
  
  // Snow animation loop
  function animateSnow() {
    snowCtx.clearRect(0, 0, snowCanvas.width, snowCanvas.height);
    
    snowflakes.forEach(snowflake => {
      snowflake.update();
      snowflake.draw();
    });
    
    snowAnimationId = requestAnimationFrame(animateSnow);
  }
  
  // Initialize snow
  function initSnow() {
    resizeSnowCanvas();
    initSnowflakes();
    animateSnow();
  }
  
  // Handle resize for snow
  let snowResizeTimeout;
  window.addEventListener('resize', () => {
    if (snowCanvas) {
      clearTimeout(snowResizeTimeout);
      snowResizeTimeout = setTimeout(() => {
        resizeSnowCanvas();
        initSnowflakes();
      }, 100);
    }
  });
  
  // Start function - call this to start snow
  window.startSnow = function() {
    if (!snowCanvas) {
      // Create canvas element
      snowCanvas = document.createElement('canvas');
      snowCanvas.id = 'snow-canvas';
      snowCanvas.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 9999;
      `;
      document.body.appendChild(snowCanvas);
      snowCtx = snowCanvas.getContext('2d');
    }
    if (!snowAnimationId) {
      initSnow();
    }
  };
  
  // Cleanup function - call this to stop snow
  window.removeSnow = function() {
    if (snowAnimationId) {
      cancelAnimationFrame(snowAnimationId);
      snowAnimationId = null;
    }
    if (snowCanvas && snowCanvas.parentNode) {
      snowCanvas.parentNode.removeChild(snowCanvas);
      snowCanvas = null;
      snowCtx = null;
    }
  };

  // ==================== FIREWORKS EFFECT ====================
  let fireworkCanvas = null;
  let fireworkCtx = null;
  let fireworkAnimationId = null;
  
  // Particle class for individual particles with trails - now as rays/streaks
  class Particle {
    constructor(x, y, vx, vy, color, life = 1, hasTrail = false, delay = 0, isLargeExplosion = false, isGlimmer = false) {
      this.x = x;
      this.y = y;
      this.vx = vx;
      this.vy = vy;
      this.originalColor = color; // Store original color
      this.color = color;
      this.life = life;
      this.isGlimmer = isGlimmer; // Whether this particle should glimmer
      this.glimmerCreated = false; // Track if glimmer particles have been created
      // Slower decay for longer particle life - even longer for large explosions
      if (isLargeExplosion) {
        this.decay = Math.random() * 0.008 + 0.005; // Even slower decay
      } else {
        this.decay = Math.random() * 0.01 + 0.008;
      }
      
      // Size variation: 40% small, 40% medium, 20% large
      const sizeRand = Math.random();
      let sizeCategory;
      if (sizeRand < 0.4) {
        sizeCategory = 'small'; // 40% small
      } else if (sizeRand < 0.8) {
        sizeCategory = 'medium'; // 40% medium
      } else {
        sizeCategory = 'large'; // 20% large
      }
      
      // Set width and length based on size category
      if (sizeCategory === 'small') {
        this.width = Math.random() * 0.8 + 0.3; // 0.3-1.1 pixels wide
        this.length = Math.random() * 10 + 5; // 5-15 pixels long
      } else if (sizeCategory === 'medium') {
        this.width = Math.random() * 1.5 + 1; // 1-2.5 pixels wide
        this.length = Math.random() * 18 + 10; // 10-28 pixels long
      } else {
        this.width = Math.random() * 2 + 2.5; // 2.5-4.5 pixels wide
        this.length = Math.random() * 25 + 20; // 20-45 pixels long
      }
      // Calculate angle from velocity
      this.angle = Math.atan2(vy, vx);
      // Increased gravity so particles fall visibly
      this.gravity = hasTrail ? 0.015 : 0.025;
      this.friction = 0.98;
      this.hasTrail = hasTrail;
      this.trail = []; // Trail positions for elegant falling effect
      this.delay = delay; // Delay before particle starts moving
      this.age = 0; // Track particle age
      this.active = delay === 0; // Whether particle is active
    }
    
    update() {
      this.age++;
      
      // Check if particle should activate (after delay)
      if (!this.active && this.age >= this.delay) {
        this.active = true;
      }
      
      // Only update if particle is active
      if (!this.active) {
        return;
      }
      
      // Add to trail if enabled (optimized update)
      if (this.hasTrail) {
        this.trail.push({ x: this.x, y: this.y, life: this.life });
        // Slightly reduced trail length for performance (still long)
        if (this.trail.length > 25) {
          this.trail.shift();
        }
        // Update trail life - optimized loop
        for (let j = this.trail.length - 1; j >= 0; j--) {
          this.trail[j].life -= 0.03;
          if (this.trail[j].life <= 0) {
            this.trail.splice(j, 1);
          }
        }
      }
      
      this.vy += this.gravity;
      this.vx *= this.friction;
      this.vy *= this.friction;
      
      // Update angle based on velocity direction
      this.angle = Math.atan2(this.vy, this.vx);
      
      this.x += this.vx;
      this.y += this.vy;
      this.life -= this.decay;
      
      // Create glimmer particles when particle dies
      if (this.isGlimmer && this.life <= 0 && !this.glimmerCreated) {
        this.glimmerCreated = true;
        // Create glimmer circles - fewer on mobile
        const isMobile = window.innerWidth <= 768;
        const maxGlimmer = isMobile ? 2 : 3;
        const glimmerCount = Math.floor(Math.random() * maxGlimmer) + (isMobile ? 2 : 3); // Mobile: 2-3, Desktop: 3-5
        for (let i = 0; i < glimmerCount; i++) {
          const angle = (Math.PI * 2 * i) / glimmerCount + Math.random() * 0.5;
          const distance = Math.random() * 3 + 1;
          const glimmerX = this.x + Math.cos(angle) * distance;
          const glimmerY = this.y + Math.sin(angle) * distance;
          glimmerParticles.push(new GlimmerParticle(glimmerX, glimmerY));
        }
      }
    }
    
    draw() {
      // Don't draw if particle hasn't activated yet
      if (!this.active) {
        return;
      }
      
      // Draw trail first if enabled - optimized drawing
      if (this.hasTrail && this.trail.length > 1) {
        fireworkCtx.save();
        fireworkCtx.strokeStyle = this.color;
        fireworkCtx.lineWidth = 1.5;
        fireworkCtx.lineCap = 'round';
        fireworkCtx.lineJoin = 'round';
        fireworkCtx.beginPath();
        
        // Draw trail with gradient opacity (optimized loop)
        const trailLength = this.trail.length;
        for (let i = 0; i < trailLength; i++) {
          const point = this.trail[i];
          const progress = i / (trailLength - 1);
          const alpha = point.life * (0.5 + progress * 0.3);
          fireworkCtx.globalAlpha = alpha;
          
          if (i === 0) {
            fireworkCtx.moveTo(point.x, point.y);
          } else {
            fireworkCtx.lineTo(point.x, point.y);
          }
        }
        fireworkCtx.stroke();
        fireworkCtx.restore();
      }
      
      // Draw particle as a small circle at the end of the trail
      fireworkCtx.save();
      fireworkCtx.globalAlpha = this.life;
      fireworkCtx.fillStyle = this.color;
      
      // Only use shadowBlur on larger particles for performance
      if (this.width > 2) {
        fireworkCtx.shadowBlur = this.width * 1.5;
        fireworkCtx.shadowColor = this.color;
      } else {
        fireworkCtx.shadowBlur = 0;
      }
      
      // Draw small circle at current position
      const radius = this.width * 0.6;
      fireworkCtx.beginPath();
      fireworkCtx.arc(this.x, this.y, radius, 0, Math.PI * 2);
      fireworkCtx.fill();
      
      fireworkCtx.restore();
    }
    
    isDead() {
      return this.life <= 0;
    }
  }
  
  // GlimmerParticle class - small white blinking circles when particles die
  class GlimmerParticle {
    constructor(x, y) {
      this.x = x;
      this.y = y;
      this.size = Math.random() * 1.5 + 1; // 1-2.5 pixels
      this.life = 1;
      this.decay = Math.random() * 0.05 + 0.03; // Fast decay for quick blink
      this.blinkSpeed = Math.random() * 0.4 + 0.3; // Fast blinking
      this.blinkPhase = Math.random() * Math.PI * 2; // Random start phase
    }
    
    update() {
      this.life -= this.decay;
      this.blinkPhase += this.blinkSpeed;
    }
    
    draw() {
      // Only draw when visible (blinking)
      const visibility = Math.sin(this.blinkPhase);
      if (visibility > 0) {
        fireworkCtx.save();
        const alpha = this.life * visibility;
        fireworkCtx.globalAlpha = alpha;
        fireworkCtx.fillStyle = '#ffffff';
        fireworkCtx.beginPath();
        fireworkCtx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        fireworkCtx.fill();
        fireworkCtx.restore();
      }
    }
    
    isDead() {
      return this.life <= 0;
    }
  }
  
  // Firework class - the rocket that goes up
  class Firework {
    constructor(startX, startY, targetX, targetY, isLarge = false, isHuge = false) {
      this.x = startX;
      this.y = startY;
      this.startX = startX;
      this.startY = startY;
      this.targetX = targetX;
      this.targetY = targetY;
      this.isLarge = isLarge; // Flag for large explosion
      this.isHuge = isHuge; // Flag for huge explosion
      
      const distance = Math.sqrt(
        Math.pow(targetX - startX, 2) + Math.pow(targetY - startY, 2)
      );
      
      this.speed = 2 + Math.random() * 2;
      // More variation in angle - more with angled trajectory
      const dx = targetX - startX;
      const dy = targetY - startY;
      // Random angle variation: 50% chance for more angle (0.8), 50% for less angle (0.4-0.6)
      const angleVariation = Math.random() < 0.5 ? 0.8 : (0.4 + Math.random() * 0.2);
      const limitedDx = dx * angleVariation;
      this.angle = Math.atan2(dy, limitedDx);
      this.vx = Math.cos(this.angle) * this.speed;
      this.vy = Math.sin(this.angle) * this.speed;
      
      this.distanceTraveled = 0;
      this.totalDistance = distance;
      this.exploded = false;
      
      // Curve effect - random direction for slight curve
      this.curveDirection = Math.random() < 0.5 ? -1 : 1; // Left or right curve
      this.curveAmount = Math.random() * 0.3 + 0.2; // Curve strength
      
      // Trail particles
      this.trail = [];
    }
    
    update() {
      if (!this.exploded) {
        // Calculate progress (0 to 1)
        const progress = this.distanceTraveled / this.totalDistance;
        
        // Reduce speed as rocket approaches explosion point (slow down in last 30% of journey)
        let speedMultiplier = 1;
        if (progress > 0.7) {
          // Gradually reduce speed from 100% to 60% as it approaches explosion
          const slowdownProgress = (progress - 0.7) / 0.3; // 0 to 1 in last 30%
          speedMultiplier = 1 - (slowdownProgress * 0.9); // Reduce by up to 40%
        }
        
        // Add slight curve - more pronounced in the middle
        const curveOffset = Math.sin(progress * Math.PI) * this.curveAmount * this.curveDirection;
        const perpendicularAngle = this.angle + Math.PI / 2; // Perpendicular to direction
        const curveX = Math.cos(perpendicularAngle) * curveOffset;
        const curveY = Math.sin(perpendicularAngle) * curveOffset;
        
        this.x += (this.vx * speedMultiplier) + curveX;
        this.y += (this.vy * speedMultiplier) + curveY;
        this.distanceTraveled = Math.sqrt(
          Math.pow(this.x - this.startX, 2) + Math.pow(this.y - this.startY, 2)
        );
        
        // Add trail particle (reduced frequency for performance)
        if (Math.random() < 0.5) { // Only add trail 50% of the time
          this.trail.push({
            x: this.x,
            y: this.y,
            life: 1,
            size: Math.random() * 2 + 1
          });
        }
        
        // Update trail - longer trail length
        if (this.trail.length > 15) {
          this.trail.shift(); // Remove oldest trail particle
        }
        this.trail.forEach((particle) => {
          particle.life -= 0.06; // Slower decay for longer trail
        });
        // Remove dead particles
        this.trail = this.trail.filter(particle => particle.life > 0);
        
        // Explode when close to target
        if (this.distanceTraveled >= this.totalDistance * 0.95) {
          this.explode();
        }
      }
    }
    
    explode() {
      this.exploded = true;
      const colors = this.getColorScheme();
      
      // Check if mobile device
      const isMobile = window.innerWidth <= 768;
      
      // Huge explosions - very large with many particles
      if (this.isHuge) {
        // Reduce particle count on mobile
        const baseCount = isMobile ? 25 : 120;
        const randomCount = isMobile ? 15 : 60;
        const particleCount = baseCount + Math.random() * randomCount; // Mobile: 25-40, Desktop: 120-180
        const hasTrails = true; // Huge explosions have trails
        
        for (let i = 0; i < particleCount; i++) {
          // Much wider angle variation for huge spread - reduced on mobile
          const baseAngle = (Math.PI * 2 * i) / particleCount;
          const angleVariationRange = isMobile ? 1.2 : 1.8; // Less spread on mobile
          const angleVariation = (Math.random() - 0.5) * angleVariationRange;
          const angle = baseAngle + angleVariation;
          
          // Variable speed - reduced on mobile for smaller spread
          const sizeRand = Math.random();
          let speed;
          if (sizeRand < 0.3) {
            speed = isMobile ? (Math.random() * 1.5 + 0.8) : (Math.random() * 2.5 + 1.5); // Mobile: 0.8-2.3, Desktop: 1.5-4
          } else if (sizeRand < 0.7) {
            speed = isMobile ? (Math.random() * 2 + 1.5) : (Math.random() * 3.5 + 3); // Mobile: 1.5-3.5, Desktop: 3-6.5
          } else {
            speed = isMobile ? (Math.random() * 2.5 + 2.5) : (Math.random() * 4 + 5); // Mobile: 2.5-5, Desktop: 5-9
          }
          
          const vx = Math.cos(angle) * speed;
          const vy = Math.sin(angle) * speed;
          const color = colors[Math.floor(Math.random() * colors.length)];
          const delay = Math.floor(Math.random() * 8); // 0-8 frames delay (optimized)
          const isGlimmer = Math.random() < 0.12; // Slightly reduced glimmer chance
          
          particles.push(new Particle(this.x, this.y, vx, vy, color, 1, hasTrails, delay, true, isGlimmer));
        }
      }
      // Large explosions have more particles and slower, elegant falling
      else if (this.isLarge) {
        // Reduce particle count on mobile
        const baseCount = isMobile ? 15 : 70;
        const randomCount = isMobile ? 8 : 30;
        const particleCount = baseCount + Math.random() * randomCount; // Mobile: 15-23, Desktop: 70-100
        const hasTrails = true; // Large explosions have trails
        
        for (let i = 0; i < particleCount; i++) {
          // More variation in angle for wider spread - reduced on mobile
          const baseAngle = (Math.PI * 2 * i) / particleCount;
          const angleVariationRange = isMobile ? 0.8 : 1.2; // Less spread on mobile
          const angleVariation = (Math.random() - 0.5) * angleVariationRange;
          const angle = baseAngle + angleVariation;
          
          // Variable speed based on size - reduced on mobile for smaller spread
          const sizeRand = Math.random();
          let speed;
          if (sizeRand < 0.4) {
            speed = isMobile ? (Math.random() * 1.2 + 0.6) : (Math.random() * 2 + 1); // Mobile: 0.6-1.8, Desktop: 1-3
          } else if (sizeRand < 0.8) {
            speed = isMobile ? (Math.random() * 1.5 + 1.2) : (Math.random() * 2.5 + 2); // Mobile: 1.2-2.7, Desktop: 2-4.5
          } else {
            speed = isMobile ? (Math.random() * 2 + 2) : (Math.random() * 3 + 3.5); // Mobile: 2-4, Desktop: 3.5-6.5
          }
          
          const vx = Math.cos(angle) * speed;
          const vy = Math.sin(angle) * speed;
          const color = colors[Math.floor(Math.random() * colors.length)];
          // Stagger particle activation for slower explosion
          const delay = Math.floor(Math.random() * 6); // 0-6 frames delay (optimized)
          // 12% chance for glimmer effect (white blinking at end)
          const isGlimmer = Math.random() < 0.12;
          
          particles.push(new Particle(this.x, this.y, vx, vy, color, 1, hasTrails, delay, true, isGlimmer));
        }
      } else {
        // Normal explosions
        // Reduce particle count on mobile
        const baseCount = isMobile ? 10 : 35;
        const randomCount = isMobile ? 8 : 25;
        const particleCount = baseCount + Math.random() * randomCount; // Mobile: 10-18, Desktop: 35-60
        const hasTrails = true; // All particles have trails
        
        for (let i = 0; i < particleCount; i++) {
          // More variation in angle for wider spread - reduced on mobile
          const baseAngle = (Math.PI * 2 * i) / particleCount;
          const angleVariationRange = isMobile ? 0.6 : 1.0; // Less spread on mobile
          const angleVariation = (Math.random() - 0.5) * angleVariationRange;
          const angle = baseAngle + angleVariation;
          
          // Variable speed based on size - reduced on mobile for smaller spread
          const sizeRand = Math.random();
          let speed;
          if (sizeRand < 0.4) {
            speed = isMobile ? (Math.random() * 1.2 + 0.8) : (Math.random() * 2.5 + 1.5); // Mobile: 0.8-2, Desktop: 1.5-4
          } else if (sizeRand < 0.8) {
            speed = isMobile ? (Math.random() * 1.5 + 1.5) : (Math.random() * 3 + 2.5); // Mobile: 1.5-3, Desktop: 2.5-5.5
          } else {
            speed = isMobile ? (Math.random() * 2 + 2.5) : (Math.random() * 3.5 + 4); // Mobile: 2.5-4.5, Desktop: 4-7.5
          }
          
          const vx = Math.cos(angle) * speed;
          const vy = Math.sin(angle) * speed;
          const color = colors[Math.floor(Math.random() * colors.length)];
          // Stagger particle activation for slower explosion
          const delay = Math.floor(Math.random() * 5); // 0-5 frames delay
          // 15% chance for glimmer effect (white blinking at end)
          const isGlimmer = Math.random() < 0.15;
          
          particles.push(new Particle(this.x, this.y, vx, vy, color, 1, hasTrails, delay, false, isGlimmer));
        }
      }
    }
    
    getColorScheme() {
      const schemes = [
        ['#ff006e', '#fb5607', '#ffbe0b', '#8338ec'],
        ['#3a86ff', '#06ffa5', '#ff006e', '#ffbe0b'],
        ['#ff006e', '#8338ec', '#3a86ff', '#06ffa5'],
        ['#ffbe0b', '#fb5607', '#ff006e', '#ffffff'],
        ['#06ffa5', '#3a86ff', '#8338ec', '#ff006e'],
        ['#ffffff', '#ffbe0b', '#fb5607', '#ff006e']
      ];
      return schemes[Math.floor(Math.random() * schemes.length)];
    }
    
    draw() {
      if (!this.exploded) {
        // Draw trail - yellow/golden color like real fireworks
        this.trail.forEach((particle, index) => {
          fireworkCtx.save();
          fireworkCtx.globalAlpha = particle.life * 0.6;
          fireworkCtx.fillStyle = '#ffbe0b'; // Golden yellow color
          fireworkCtx.beginPath();
          fireworkCtx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
          fireworkCtx.fill();
          fireworkCtx.restore();
        });
        
        // Draw rocket (optimized - reduced shadowBlur)
        fireworkCtx.save();
        fireworkCtx.fillStyle = '#ffffff';
        fireworkCtx.shadowBlur = 8; // Reduced from 15 for better performance
        fireworkCtx.shadowColor = '#ffffff';
        fireworkCtx.beginPath();
        fireworkCtx.arc(this.x, this.y, 3, 0, Math.PI * 2);
        fireworkCtx.fill();
        fireworkCtx.restore();
      }
    }
  }
  
  // Arrays to hold fireworks and particles
  const fireworks = [];
  const particles = [];
  const glimmerParticles = [];
  
  // Configuration (optimized intervals for better performance)
  const config = {
    fireworkInterval: 2500, // milliseconds between fireworks
    minInterval: 2000,
    maxInterval: 3500
  };
  
  let lastFireworkTime = 0;
  
  // Create fireworks - multiple at once with variation
  function createFirework() {
    // Create 1-2 fireworks at once (reduced for performance)
    const count = Math.floor(Math.random() * 4) + 1; // 1-2 fireworks
    
    for (let i = 0; i < count; i++) {
      const startX = Math.random() * fireworkCanvas.width;
      const startY = fireworkCanvas.height;
      // More variation in target - more with angled trajectory
      const angleVariation = Math.random() < 0.5 ? 0.6 : 0.3; // 50% chance for more angle
      const targetX = startX + (Math.random() - 0.5) * (fireworkCanvas.width * angleVariation);
      const targetY = Math.random() * (fireworkCanvas.height * 0.35) + 50; // Upper 35% of screen
      
      // Determine explosion size: 10% huge, 20% large, 70% normal
      const rand = Math.random();
      const isHuge = rand < 0.1; // 10% chance for huge explosion
      const isLarge = !isHuge && rand < 0.3; // 20% chance for large explosion
      
      // Stagger launch slightly for visual effect
      setTimeout(() => {
        fireworks.push(new Firework(startX, startY, targetX, targetY, isLarge, isHuge));
      }, i * 100); // 100ms delay between each firework
    }
  }
  
  // Resize firework canvas
  function resizeFireworkCanvas() {
    fireworkCanvas.width = window.innerWidth;
    fireworkCanvas.height = window.innerHeight;
  }
  
  // Firework animation loop
  function animateFireworks(currentTime) {
    // Clear canvas with transparent background
    fireworkCtx.clearRect(0, 0, fireworkCanvas.width, fireworkCanvas.height);
    
    // Create new firework at intervals
    if (currentTime - lastFireworkTime > config.fireworkInterval) {
      createFirework();
      lastFireworkTime = currentTime;
      config.fireworkInterval = config.minInterval + Math.random() * (config.maxInterval - config.minInterval);
    }
    
    // Update and draw fireworks
    for (let i = fireworks.length - 1; i >= 0; i--) {
      fireworks[i].update();
      fireworks[i].draw();
      
      if (fireworks[i].exploded) {
        fireworks.splice(i, 1);
      }
    }
    
    // Update and draw particles
    for (let i = particles.length - 1; i >= 0; i--) {
      particles[i].update();
      particles[i].draw();
      
      if (particles[i].isDead()) {
        particles.splice(i, 1);
      }
    }
    
    // Update and draw glimmer particles (small white blinking circles)
    for (let i = glimmerParticles.length - 1; i >= 0; i--) {
      glimmerParticles[i].update();
      glimmerParticles[i].draw();
      
      if (glimmerParticles[i].isDead()) {
        glimmerParticles.splice(i, 1);
      }
    }
    
    fireworkAnimationId = requestAnimationFrame(animateFireworks);
  }
  
  // Initialize fireworks
  function initFireworks() {
    resizeFireworkCanvas();
    
    // Start with fewer fireworks for better initial performance
    setTimeout(() => {
      createFirework();
    }, 500);
    
    lastFireworkTime = performance.now();
    animateFireworks(performance.now());
  }
  
  // Handle resize for fireworks
  let fireworkResizeTimeout;
  window.addEventListener('resize', () => {
    if (fireworkCanvas) {
      clearTimeout(fireworkResizeTimeout);
      fireworkResizeTimeout = setTimeout(() => {
        resizeFireworkCanvas();
      }, 100);
    }
  });
  
  // Start function - call this to start fireworks
  window.startFireworks = function() {
    if (!fireworkCanvas) {
      // Create canvas element
      fireworkCanvas = document.createElement('canvas');
      fireworkCanvas.id = 'firework-canvas';
      fireworkCanvas.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 9998;
      `;
      document.body.appendChild(fireworkCanvas);
      fireworkCtx = fireworkCanvas.getContext('2d');
    }
    if (!fireworkAnimationId) {
      initFireworks();
    }
  };
  
  // Cleanup function - call this to stop fireworks
  window.removeFireworks = function() {
    if (fireworkAnimationId) {
      cancelAnimationFrame(fireworkAnimationId);
      fireworkAnimationId = null;
    }
    if (fireworkCanvas && fireworkCanvas.parentNode) {
      fireworkCanvas.parentNode.removeChild(fireworkCanvas);
      fireworkCanvas = null;
      fireworkCtx = null;
    }
  };
})();

